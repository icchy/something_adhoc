# for backwards compatibility
from .iwconfig import get_iwconfig
