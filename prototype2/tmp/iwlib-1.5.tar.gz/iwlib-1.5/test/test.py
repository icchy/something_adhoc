from iwlib import iwlist

print iwlist.scan('wlan0')
print iwlist.scan('wlan0')
