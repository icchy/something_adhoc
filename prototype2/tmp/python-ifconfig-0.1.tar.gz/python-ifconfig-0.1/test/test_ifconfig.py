#!/usr/bin/env python

import unittest
import ifconfig


class IfconfigTestCase(unittest.TestCase):
    def test_ifconfig(self):
        print ifconfig.ifconfig('eth0')


if __name__ == '__main__':
    unittest.main()
