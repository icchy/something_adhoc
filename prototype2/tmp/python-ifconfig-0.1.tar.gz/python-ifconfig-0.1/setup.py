#!/usr/bin/env python

from distutils.core import setup, Extension

setup(name = 'python-ifconfig',
      version = '0.1',
      description = 'Display network interface status.',
      author = 'Zhigang Wang',
      author_email = 'w1z2g3@gmail.com',
      license = 'GPL',
      url = 'http://code.google.com/p/python-ifconfig/',
      classifiers = [
          'Development Status :: 6 - Mature',
          'License :: OSI Approved :: GNU General Public License',
          'Natural Language :: English',
          'Operating System :: POSIX',
          'Programming Language :: C',
          'Programming Language :: Python',
          'Topic :: System :: Networking'],
      ext_modules = [
          Extension('ifconfig', sources=['ifconfig.c'])])
