/*
 * Copyright (C) 1999 Linuxcare Inc.
 *
 * Authors:
 *  David N. Welton <davidw at linuxcare.com>
 *  Zhigang Wang <w1z2g3 at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <Python.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/in.h>
#include <arpa/inet.h>

static PyObject *pyifconfig(PyObject *self, PyObject *args)
{
    int fd;

    struct ifreq ifreq;
    unsigned char *hw;
    struct sockaddr_in *sin;
    char *itf;

    char hwaddr[40];
    char addr[20];
    char brdaddr[20];
    char netmask[20];

    if (!PyArg_ParseTuple(args, "s", &itf))
	return NULL;

    fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);

    strcpy(ifreq.ifr_name, itf);

    /* hardware address */
    ioctl(fd, SIOCGIFHWADDR, &ifreq);
    hw = ifreq.ifr_hwaddr.sa_data;
    sprintf(hwaddr, "%02x:%02x:%02x:%02x:%02x:%02x",
	    *hw, *(hw + 1), *(hw + 2), *(hw + 3), *(hw + 4), *(hw + 5));

    /* address */
    ioctl(fd, SIOCGIFADDR, &ifreq);
    sin = (struct sockaddr_in *)&ifreq.ifr_broadaddr;
    sprintf(addr, "%s", inet_ntoa(sin->sin_addr));

    /* broadcast */
    ioctl(fd, SIOCGIFBRDADDR, &ifreq);
    sin = (struct sockaddr_in *)&ifreq.ifr_broadaddr;
    sprintf(brdaddr, "%s", inet_ntoa(sin->sin_addr));

    /* netmask */
    ioctl(fd, SIOCGIFNETMASK, &ifreq);
    sin = (struct sockaddr_in *)&ifreq.ifr_broadaddr;
    sprintf(netmask, "%s", inet_ntoa(sin->sin_addr));

    close(fd);
    return Py_BuildValue("{s:s,s:s,s:s,s:s}",
			 "hwaddr", hwaddr,
			 "addr", addr,
			 "brdaddr", brdaddr,
			 "netmask", netmask);
}

static struct PyMethodDef ifconfig_methods[] = {
    {"ifconfig",
        pyifconfig,
        METH_VARARGS,
        /*METH_VARARGS | METH_KEYWORDS,*/
        "Displays the interface status.\n"},
    {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC initifconfig()
{
    Py_InitModule3("ifconfig", ifconfig_methods,
                   "Display network interface status.\n");
}
